# Gate Protocol

The hardware protocol is pending Phase 3. Do not connect a physical gate until the protocol, authentication/MAC behavior, auto-close, and failure cases have been implemented and tested.
