from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True)
class GateResult:
    success: bool
    message: str


class GateController(Protocol):
    async def start(self) -> None: ...
    async def stop(self) -> None: ...
    async def open_gate(self, request_id: str, ttl_ms: int) -> GateResult: ...
    async def close_gate(self) -> GateResult: ...
