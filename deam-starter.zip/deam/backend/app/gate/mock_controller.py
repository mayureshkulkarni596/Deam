from .base import GateResult


class MockGateController:
    """Development-only mock. It does not control physical hardware."""

    async def start(self) -> None:
        return None

    async def stop(self) -> None:
        return None

    async def open_gate(self, request_id: str, ttl_ms: int) -> GateResult:
        print(f"[MOCK] Would open gate for request={request_id}, ttl_ms={ttl_ms}")
        return GateResult(success=True, message="Mock open simulated")

    async def close_gate(self) -> GateResult:
        print("[MOCK] Would close gate")
        return GateResult(success=True, message="Mock close simulated")
