from fastapi import FastAPI

app = FastAPI(
    title="Smart Society Gate API",
    version="0.1.0",
    description="Local-first smart society gate API starter.",
)


@app.get("/health", tags=["system"])
async def health() -> dict[str, str]:
    return {
        "status": "ok",
        "hardware_mode": "mock",
        "note": "Starter scaffold only; full safety and readiness checks are not implemented yet.",
    }
