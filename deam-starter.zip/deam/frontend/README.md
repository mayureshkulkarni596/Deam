# Frontend

React + TypeScript + Vite frontend will be implemented in Phase 2. No frontend app is scaffolded yet.
