# Smart Society Gate

A local-first AI-assisted smart society gate project for a college project. The software verifies registered visitors using a PIN and face matching, routes guest requests to residents for approval, and communicates with an Arduino gate controller over USB serial.

> **Safety invariant:** Only the backend decision engine may command the gate. The system is fail-closed: if verification, the database, the AI model, networking, or hardware communication fails, the gate remains closed.

## Project status

This is a starter scaffold, not a completed application. Implement in phases and test with mock hardware before connecting a real gate.

- [ ] Phase 0: Foundation
- [ ] Phase 1: Core MVP (registered and guest visitors)
- [ ] Phase 2: Frontend MVP
- [ ] Phase 3: Arduino hardware integration
- [ ] Phase 4: Admin, passes, and polish
- [ ] Phase 5: Optional stretch features

## Stack

- Python 3.11+, FastAPI, Pydantic v2, SQLAlchemy 2.x, Alembic
- SQLite for development/tests; MySQL 8 for production
- JWT bearer authentication and Argon2id/bcrypt password hashing
- OpenCV YuNet face detection and SFace recognition using ONNX models
- pyserial, with mock and serial gate-controller implementations
- React 18, TypeScript, Vite, Tailwind CSS, shadcn/ui
- pytest, pytest-asyncio, httpx; planned frontend tests with Vitest and Playwright

## Entry modes

1. **Registered visitor:** PIN, face verification, schedule, and resident-configured automatic opening or approval.
2. **Guest:** Name and purpose are submitted to the resident for approval. The gate stays closed until approved.
3. **Delivery pass (stretch):** Time-limited, single-use pass.

## Safety and privacy

- Fail closed on every error in the gate decision path.
- Keep gate-controller access inside the decision-engine boundary.
- Use mock mode during development; no Arduino is required for the initial MVP.
- Keep secrets in `.env`; never commit real credentials.
- Face embeddings and snapshots are personal data. Restrict access, obtain consent, and enforce retention/deletion.
- Face matching without liveness detection can be spoofed by a printed photo.
- Test all behavior with mock hardware before real hardware is connected.

## Initial setup

1. Install Python 3.11 or newer and Node.js.
2. Copy `backend/.env.example` to `backend/.env` and replace the development secrets.
3. Create a Python virtual environment and install backend requirements:
   ```bash
   cd backend
   python -m venv .venv
   # Windows: .venv\Scripts\activate
   # macOS/Linux: source .venv/bin/activate
   pip install -r requirements.txt
   uvicorn app.main:app --reload
   ```
4. Open `http://127.0.0.1:8000/health`.

The current scaffold only provides a health endpoint and mock gate interface. Authentication, database models, face verification, and the full UI are not implemented yet.

## Planned layout

```text
deam/
├── backend/
│   ├── app/
│   │   ├── gate/
│   │   ├── services/
│   │   └── main.py
│   ├── tests/
│   └── requirements.txt
├── frontend/
├── hardware-spec/
├── docs/
├── .gitignore
└── README.md
```

## License

Choose a license before publishing a reusable release.
