# Architecture

Planned flow:

Kiosk / resident browser → FastAPI backend → decision engine → gate controller interface → USB serial → Arduino.

Only the backend decision engine may authorize opening. The frontend must never communicate directly with gate hardware. Any verification, database, model, network, or hardware failure must keep the gate closed.
